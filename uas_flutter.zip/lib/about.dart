import 'package:flutter/material.dart';
import 'package:uas_flutter/main.dart';
import 'package:uas_flutter/home_page.dart';

class About extends StatefulWidget {
  @override
  _AboutState createState() => _AboutState();
}

class _AboutState extends State<About> {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
             child: Center(
              child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                child: Image.asset(
                  "images/logo.png",
                  height: 100,
                ),
                child: Text("Kelompok 4")
                child: Text("Kelompok 4")
              ),
            ],
          )),
          ),
        ),
      ),
    );
  }
}
